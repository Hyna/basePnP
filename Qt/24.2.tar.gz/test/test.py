# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created: Tue Feb 24 01:55:06 2015
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName(_fromUtf8("MainWindow"))
        MainWindow.resize(1162, 710)
        self.centralWidget = QtGui.QWidget(MainWindow)
        self.centralWidget.setObjectName(_fromUtf8("centralWidget"))
        self.btnLoadTst = QtGui.QPushButton(self.centralWidget)
        self.btnLoadTst.setGeometry(QtCore.QRect(20, 50, 171, 31))
        self.btnLoadTst.setObjectName(_fromUtf8("btnLoadTst"))
        self.groupBox = QtGui.QGroupBox(self.centralWidget)
        self.groupBox.setGeometry(QtCore.QRect(230, 10, 211, 111))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.radioOrigin = QtGui.QRadioButton(self.groupBox)
        self.radioOrigin.setGeometry(QtCore.QRect(10, 30, 110, 41))
        self.radioOrigin.setChecked(True)
        self.radioOrigin.setObjectName(_fromUtf8("radioOrigin"))
        self.radioGeometric = QtGui.QRadioButton(self.groupBox)
        self.radioGeometric.setGeometry(QtCore.QRect(10, 70, 181, 26))
        self.radioGeometric.setObjectName(_fromUtf8("radioGeometric"))
        self.btnLoadPlacement = QtGui.QPushButton(self.centralWidget)
        self.btnLoadPlacement.setGeometry(QtCore.QRect(20, 10, 171, 31))
        self.btnLoadPlacement.setObjectName(_fromUtf8("btnLoadPlacement"))
        self.btnLoadCCD = QtGui.QPushButton(self.centralWidget)
        self.btnLoadCCD.setGeometry(QtCore.QRect(20, 90, 171, 31))
        self.btnLoadCCD.setObjectName(_fromUtf8("btnLoadCCD"))
        self.line = QtGui.QFrame(self.centralWidget)
        self.line.setGeometry(QtCore.QRect(10, 130, 601, 16))
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.label_2 = QtGui.QLabel(self.centralWidget)
        self.label_2.setGeometry(QtCore.QRect(20, 140, 181, 21))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.treeWidget = QtGui.QTreeWidget(self.centralWidget)
        self.treeWidget.setGeometry(QtCore.QRect(20, 160, 441, 241))
        self.treeWidget.setAlternatingRowColors(True)
        self.treeWidget.setColumnCount(8)
        self.treeWidget.setObjectName(_fromUtf8("treeWidget"))
        self.treeWidget.header().setHighlightSections(False)
        self.treePackages = QtGui.QTreeWidget(self.centralWidget)
        self.treePackages.setGeometry(QtCore.QRect(20, 430, 441, 221))
        self.treePackages.setAlternatingRowColors(True)
        self.treePackages.setObjectName(_fromUtf8("treePackages"))
        self.treePackages.headerItem().setText(0, _fromUtf8("1"))
        self.label_3 = QtGui.QLabel(self.centralWidget)
        self.label_3.setGeometry(QtCore.QRect(20, 410, 181, 21))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.comboBox = QtGui.QComboBox(self.centralWidget)
        self.comboBox.setGeometry(QtCore.QRect(590, 550, 83, 29))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.dial = QtGui.QDial(self.centralWidget)
        self.dial.setGeometry(QtCore.QRect(520, 540, 50, 64))
        self.dial.setObjectName(_fromUtf8("dial"))
        self.imgCCD = QtGui.QLabel(self.centralWidget)
        self.imgCCD.setGeometry(QtCore.QRect(480, 160, 671, 361))
        self.imgCCD.setFrameShape(QtGui.QFrame.Box)
        self.imgCCD.setObjectName(_fromUtf8("imgCCD"))
        self.lblAbout = QtGui.QLabel(self.centralWidget)
        self.lblAbout.setGeometry(QtCore.QRect(590, 50, 181, 31))
        self.lblAbout.setObjectName(_fromUtf8("lblAbout"))
        self.label = QtGui.QLabel(self.centralWidget)
        self.label.setGeometry(QtCore.QRect(480, 140, 201, 21))
        self.label.setObjectName(_fromUtf8("label"))
        self.lblStatus = QtGui.QLabel(self.centralWidget)
        self.lblStatus.setGeometry(QtCore.QRect(550, 520, 441, 21))
        self.lblStatus.setObjectName(_fromUtf8("lblStatus"))
        self.label_4 = QtGui.QLabel(self.centralWidget)
        self.label_4.setGeometry(QtCore.QRect(490, 520, 51, 21))
        self.label_4.setObjectName(_fromUtf8("label_4"))
        MainWindow.setCentralWidget(self.centralWidget)
        self.menuBar = QtGui.QMenuBar(MainWindow)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 1162, 27))
        self.menuBar.setObjectName(_fromUtf8("menuBar"))
        MainWindow.setMenuBar(self.menuBar)
        self.mainToolBar = QtGui.QToolBar(MainWindow)
        self.mainToolBar.setObjectName(_fromUtf8("mainToolBar"))
        MainWindow.addToolBar(QtCore.Qt.TopToolBarArea, self.mainToolBar)
        self.statusBar = QtGui.QStatusBar(MainWindow)
        self.statusBar.setObjectName(_fromUtf8("statusBar"))
        MainWindow.setStatusBar(self.statusBar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(_translate("MainWindow", "PnP test application", None))
        self.btnLoadTst.setText(_translate("MainWindow", "Load board image", None))
        self.groupBox.setTitle(_translate("MainWindow", "Origins vs geomtertic center", None))
        self.radioOrigin.setText(_translate("MainWindow", "Origins", None))
        self.radioGeometric.setText(_translate("MainWindow", "Pads geometric center", None))
        self.btnLoadPlacement.setText(_translate("MainWindow", "Load PnP Eagle data", None))
        self.btnLoadCCD.setText(_translate("MainWindow", "Take a CCD image", None))
        self.label_2.setText(_translate("MainWindow", "Eagle placement data", None))
        self.treeWidget.headerItem().setText(0, _translate("MainWindow", "1", None))
        self.treeWidget.headerItem().setText(1, _translate("MainWindow", "2", None))
        self.treeWidget.headerItem().setText(2, _translate("MainWindow", "3", None))
        self.treeWidget.headerItem().setText(3, _translate("MainWindow", "4", None))
        self.treeWidget.headerItem().setText(4, _translate("MainWindow", "5", None))
        self.treeWidget.headerItem().setText(5, _translate("MainWindow", "6", None))
        self.treeWidget.headerItem().setText(6, _translate("MainWindow", "7", None))
        self.treeWidget.headerItem().setText(7, _translate("MainWindow", "8", None))
        self.label_3.setText(_translate("MainWindow", "Items for placement", None))
        self.comboBox.setItemText(0, _translate("MainWindow", "tray 1", None))
        self.comboBox.setItemText(1, _translate("MainWindow", "tray 2", None))
        self.comboBox.setItemText(2, _translate("MainWindow", "tray 3", None))
        self.imgCCD.setText(_translate("MainWindow", "Image from CCD", None))
        self.lblAbout.setText(_translate("MainWindow", "PnP SW by Hynek Stetina\n"
"VUTBR", None))
        self.label.setText(_translate("MainWindow", "Placement simulator", None))
        self.lblStatus.setText(_translate("MainWindow", "Board is not aligned!", None))
        self.label_4.setText(_translate("MainWindow", "Status:", None))

